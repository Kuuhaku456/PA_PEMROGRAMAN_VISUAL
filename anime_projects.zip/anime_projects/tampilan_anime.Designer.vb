﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class tampilan_anime
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Me.label_episode = New System.Windows.Forms.Label()
        Me.label_judul = New System.Windows.Forms.Label()
        Me.label_hari = New System.Windows.Forms.Label()
        Me.label_tanggal = New System.Windows.Forms.Label()
        Me.label_rating = New System.Windows.Forms.Label()
        Me.label_sinopsis = New System.Windows.Forms.RichTextBox()
        Me.label_genre = New System.Windows.Forms.Label()
        Me.label_studio = New System.Windows.Forms.Label()
        Me.label_tipe = New System.Windows.Forms.Label()
        Me.PB_ANIME = New System.Windows.Forms.PictureBox()
        Me.label_path = New System.Windows.Forms.Label()
        Me.Label_id = New System.Windows.Forms.Label()
        CType(Me.PB_ANIME, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'label_episode
        '
        Me.label_episode.AutoSize = True
        Me.label_episode.Font = New System.Drawing.Font("Segoe UI", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.label_episode.Location = New System.Drawing.Point(5, 6)
        Me.label_episode.Name = "label_episode"
        Me.label_episode.Size = New System.Drawing.Size(67, 25)
        Me.label_episode.TabIndex = 1
        Me.label_episode.Text = "Label1"
        '
        'label_judul
        '
        Me.label_judul.BackColor = System.Drawing.Color.LightGray
        Me.label_judul.Dock = System.Windows.Forms.DockStyle.Bottom
        Me.label_judul.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.label_judul.Font = New System.Drawing.Font("Franklin Gothic Book", 8.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.label_judul.Location = New System.Drawing.Point(0, 194)
        Me.label_judul.Name = "label_judul"
        Me.label_judul.Size = New System.Drawing.Size(247, 53)
        Me.label_judul.TabIndex = 2
        Me.label_judul.Text = "Label2"
        Me.label_judul.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.label_judul.Visible = False
        '
        'label_hari
        '
        Me.label_hari.AutoSize = True
        Me.label_hari.BackColor = System.Drawing.SystemColors.Highlight
        Me.label_hari.Font = New System.Drawing.Font("Segoe UI", 11.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.label_hari.Location = New System.Drawing.Point(166, 75)
        Me.label_hari.Name = "label_hari"
        Me.label_hari.Size = New System.Drawing.Size(81, 30)
        Me.label_hari.TabIndex = 3
        Me.label_hari.Text = "Label3"
        '
        'label_tanggal
        '
        Me.label_tanggal.AutoSize = True
        Me.label_tanggal.Font = New System.Drawing.Font("Segoe UI", 8.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.label_tanggal.Location = New System.Drawing.Point(1, 42)
        Me.label_tanggal.Name = "label_tanggal"
        Me.label_tanggal.Size = New System.Drawing.Size(60, 21)
        Me.label_tanggal.TabIndex = 4
        Me.label_tanggal.Text = "Label4"
        '
        'label_rating
        '
        Me.label_rating.AutoSize = True
        Me.label_rating.Location = New System.Drawing.Point(1, 203)
        Me.label_rating.Name = "label_rating"
        Me.label_rating.Size = New System.Drawing.Size(57, 20)
        Me.label_rating.TabIndex = 5
        Me.label_rating.Text = "Label1"
        Me.label_rating.Visible = False
        '
        'label_sinopsis
        '
        Me.label_sinopsis.Location = New System.Drawing.Point(171, 151)
        Me.label_sinopsis.Name = "label_sinopsis"
        Me.label_sinopsis.Size = New System.Drawing.Size(81, 96)
        Me.label_sinopsis.TabIndex = 6
        Me.label_sinopsis.Text = ""
        Me.label_sinopsis.Visible = False
        '
        'label_genre
        '
        Me.label_genre.AutoSize = True
        Me.label_genre.Location = New System.Drawing.Point(1, 174)
        Me.label_genre.Name = "label_genre"
        Me.label_genre.Size = New System.Drawing.Size(57, 20)
        Me.label_genre.TabIndex = 7
        Me.label_genre.Text = "Label1"
        Me.label_genre.Visible = False
        '
        'label_studio
        '
        Me.label_studio.AutoSize = True
        Me.label_studio.Location = New System.Drawing.Point(1, 135)
        Me.label_studio.Name = "label_studio"
        Me.label_studio.Size = New System.Drawing.Size(57, 20)
        Me.label_studio.TabIndex = 8
        Me.label_studio.Text = "Label1"
        Me.label_studio.Visible = False
        '
        'label_tipe
        '
        Me.label_tipe.AutoSize = True
        Me.label_tipe.Location = New System.Drawing.Point(1, 115)
        Me.label_tipe.Name = "label_tipe"
        Me.label_tipe.Size = New System.Drawing.Size(57, 20)
        Me.label_tipe.TabIndex = 10
        Me.label_tipe.Text = "Label1"
        Me.label_tipe.Visible = False
        '
        'PB_ANIME
        '
        Me.PB_ANIME.Dock = System.Windows.Forms.DockStyle.Fill
        Me.PB_ANIME.Location = New System.Drawing.Point(0, 0)
        Me.PB_ANIME.Name = "PB_ANIME"
        Me.PB_ANIME.Size = New System.Drawing.Size(247, 247)
        Me.PB_ANIME.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.PB_ANIME.TabIndex = 0
        Me.PB_ANIME.TabStop = False
        '
        'label_path
        '
        Me.label_path.AutoSize = True
        Me.label_path.Location = New System.Drawing.Point(1, 95)
        Me.label_path.Name = "label_path"
        Me.label_path.Size = New System.Drawing.Size(57, 20)
        Me.label_path.TabIndex = 11
        Me.label_path.Text = "Label1"
        Me.label_path.Visible = False
        '
        'Label_id
        '
        Me.Label_id.AutoSize = True
        Me.Label_id.Location = New System.Drawing.Point(1, 75)
        Me.Label_id.Name = "Label_id"
        Me.Label_id.Size = New System.Drawing.Size(57, 20)
        Me.Label_id.TabIndex = 12
        Me.Label_id.Text = "Label1"
        Me.Label_id.Visible = False
        '
        'tampilan_anime
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(9.0!, 20.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.SystemColors.ActiveCaption
        Me.ClientSize = New System.Drawing.Size(247, 247)
        Me.Controls.Add(Me.Label_id)
        Me.Controls.Add(Me.label_path)
        Me.Controls.Add(Me.label_tipe)
        Me.Controls.Add(Me.label_studio)
        Me.Controls.Add(Me.label_genre)
        Me.Controls.Add(Me.label_sinopsis)
        Me.Controls.Add(Me.label_rating)
        Me.Controls.Add(Me.label_tanggal)
        Me.Controls.Add(Me.label_hari)
        Me.Controls.Add(Me.label_judul)
        Me.Controls.Add(Me.label_episode)
        Me.Controls.Add(Me.PB_ANIME)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None
        Me.Name = "tampilan_anime"
        Me.Text = "tampilan_anime"
        CType(Me.PB_ANIME, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents PB_ANIME As PictureBox
    Friend WithEvents label_episode As Label
    Friend WithEvents label_judul As Label
    Friend WithEvents label_hari As Label
    Friend WithEvents label_tanggal As Label
    Friend WithEvents label_rating As Label
    Friend WithEvents label_sinopsis As RichTextBox
    Friend WithEvents label_genre As Label
    Friend WithEvents label_studio As Label
    Friend WithEvents label_tipe As Label
    Friend WithEvents label_path As Label
    Friend WithEvents Label_id As Label
End Class
