﻿Imports MySql.Data.MySqlClient

Public Class template
    Sub changeContent(ByVal panel As Form)
        panel.TopLevel = False
        FlowLayoutPanel1.Controls.Add(panel)
        panel.Show()
    End Sub
    Private Sub template_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        connect()
        Dim sql As String = "SELECT judul, studio, rating, tipe, status, episode, genre, tanggal_rilis, sinopsis, gambar FROM tb_ongoing UNION SELECT judul, studio, rating, tipe, status, episode, genre, tanggal_rilis, sinopsis, gambar FROM tb_completed"
        CMD = New MySqlCommand(sql, CONN)
        RD = CMD.ExecuteReader()
        While RD.Read()
            Dim anime As New tampilan_anime
            anime.label_judul.Text = RD("judul")
            'anime.Cells(0).Value = RD("judul")
            'anime.Cells(1).Value = RD("studio")
            'anime.Cells(2).Value = RD("rating")
            'anime.Cells(3).Value = RD("tipe")
            'anime.Cells(4).Value = RD("status")
            'anime.Cells(5).Value = RD("episode")
            'anime.Cells(6).Value = RD("genre")
            'anime.Cells(7).Value = RD("tanggal_rilis")
            'anime.Cells(8).Value = RD("sinopsis")
            'anime.Cells(9).Value = RD("gambar")
            'data_anime.Rows.Add(anime)
            anime.TopLevel = False
            FlowLayoutPanel1.Controls.Add(anime)
            anime.Show()
        End While

    End Sub

End Class