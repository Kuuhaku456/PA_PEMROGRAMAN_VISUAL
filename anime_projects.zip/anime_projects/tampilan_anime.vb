﻿Imports MySql.Data.MySqlClient

Public Class tampilan_anime
    Private Sub PB_ANIME_Click(sender As Object, e As EventArgs) Handles PB_ANIME.Click
        main_user.pnl_main.Controls.Clear()
        Dim newForm = New detail_animevb
        newForm.TopLevel = False
        newForm.AutoScroll = True
        newForm.judul_txt.Text = label_judul.Text
        newForm.studio_txt.Text = label_studio.Text
        newForm.rating_txt.Text = label_rating.Text
        newForm.episode_txt.Text = label_episode.Text
        newForm.genre_txt.Text = label_genre.Text
        newForm.tipe_txt.Text = label_tipe.Text
        newForm.sinopsis_txt.Text = label_sinopsis.Text
        newForm.tanggal_rilis_txt.Text = label_tanggal.Text
        newForm.pb_anime.Image = PB_ANIME.Image
        newForm.path_gambar_txt.Text = label_path.Text
        main_user.pnl_main.Controls.Add(newForm)
        newForm.Show()
    End Sub
    Private Sub PB_ANIME_MouseEnter(sender As Object, e As EventArgs) Handles PB_ANIME.MouseEnter
        label_judul.Visible = True
    End Sub

    Private Sub PB_ANIME_MouseLeave(sender As Object, e As EventArgs) Handles PB_ANIME.MouseLeave
        label_judul.Visible = False
    End Sub
End Class